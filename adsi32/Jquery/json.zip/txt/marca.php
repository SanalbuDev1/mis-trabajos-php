
	<?php 

		if($_GET){

			$marca = $_GET['marca'];

			if($marca == 1){
				echo "<option >Hig</option>
				 <option>Hig</option>
				 <option>Hig</option>";
			}
			if ($marca == 2) {
				echo "<option >Hig</option>
				 <option >Hig</option>
				 <option >Hig</option>";
				
				

			}

		}

	 ?>
