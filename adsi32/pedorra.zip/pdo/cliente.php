<?php 
	require 'config/app.php' ;
	require 'config/database.php';
	require 'config/security_cliente.php';
	include 'template/header.inc';
	include 'template/navbar.inc';

?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<h1>Bienvenido <?=$_SESSION['unombres'];?></h1>
			<hr>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore perferendis accusantium deserunt qui numquam, nemo repellat aperiam ducimus, maiores magnam nostrum illum quasi incidunt obcaecati blanditiis molestias, accusamus impedit nesciunt labore, dolores rerum. Maxime amet reprehenderit asperiores officia illum tempora voluptates ea vel, soluta, dolorum dolor explicabo sint provident ex veritatis molestias ducimus inventore dignissimos voluptatibus eaque quisquam ab dolorem. Fugit cupiditate tempore molestias ipsum aperiam, labore asperiores nisi officia eius tenetur architecto consequuntur, reprehenderit illum beatae culpa ut veniam facilis dolorem minus quaerat, maiores assumenda ipsa aliquam! Et ab illum, repellat nobis corporis exercitationem fugiat officiis dicta reiciendis praesentium!</p>
		</div>
	</div>
</div>

<?php include 'template/footer.inc'; ?>