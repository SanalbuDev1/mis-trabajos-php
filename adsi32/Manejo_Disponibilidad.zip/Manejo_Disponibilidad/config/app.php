<?php 
	$base_url = 'http://localhost/adsi32/Manejo_Disponibilidad/';
	$base_css = $base_url.'css/';
	$base_js = $base_url.'js/';
	$base_imgs = $base_url.'imgs/';

	//base de datos
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$ndb = 'manejo_dis';
	$con= null;
	$stm = null;


	

